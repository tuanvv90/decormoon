<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartbloghomelatestnews}prestashop>smartblog_latest_news_099afb04ddf259fff6a50c50d7eae060'] = ' সর্বশেষ সংবাদ';
